from mipt_wann.wann_node import WANNNode
from mipt_wann.wann import WANN
